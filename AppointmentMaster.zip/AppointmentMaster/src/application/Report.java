package application;

import javafx.beans.property.SimpleStringProperty;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Report {
    private String serviceAgent = new String("");
    private String customerName = new String("");
    private ZonedDateTime appointmentStart;
    private String count = new String("");
    private String appointmentType = new String("");




    public Report() {}

    public Report(String appType, String c) {
        appointmentType = appType;
        count = c;
    }

    public Report(String sAgent, ZonedDateTime appS) {
        serviceAgent = sAgent;
        appointmentStart = appS;
    }

    public Report(String sAgent, String appType, String c) {
        serviceAgent = sAgent;
        appointmentType = appType;
        count = c;
    }

    public Report(String sAgent, String cName, ZonedDateTime appS, String c, String appT, Integer appId) {
        serviceAgent = sAgent;
        customerName = cName;
        appointmentStart = appS;
        count = c;
        appointmentType = appT;


    }

    public String getCustomerName(){

        return customerName;
    }

    public void setCustomerName(String cName){

        customerName = cName;
    }


    public String getServiceAgent(){
        return serviceAgent;
    }

    public void setServiceAgent(String SAgent){
        serviceAgent = SAgent;
    }

    public ZonedDateTime getAppointmentStart(){
        return appointmentStart;
    }

    public void setAppointmentStart(ZonedDateTime appS){appointmentStart = appS;}

    public String getCount(){
        return count;
    }

    public void setCount(String c){
        count = c;
    }

    public String getAppointmentType(){
        return appointmentType;
    }

    public void setAppointmentType(String appT){
        appointmentType = appT;
    }


}
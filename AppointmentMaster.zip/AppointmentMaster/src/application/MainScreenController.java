package application;

import DAO.AppointmentDaoImpl;
import DAO.CustomerDaoImpl;
import DAO.Query;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.ComboBoxTableCell;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.util.StringConverter;
import javafx.util.converter.LocalDateTimeStringConverter;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.*;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MainScreenController implements Initializable {

    @FXML GridPane mainScreen;

    //Buttons


    @FXML protected void handleCustomerButtonAction(ActionEvent event) throws IOException {
        GridPane customerScreen = FXMLLoader.load(getClass().getResource("customerScreen.fxml"));
        mainScreen.getChildren().setAll(customerScreen);
    }

    @FXML protected void handleNewAppointmentAction(ActionEvent event) throws IOException {
        GridPane newAppointmentScreen = FXMLLoader.load(getClass().getResource("newAppointmentScreen.fxml"));
        mainScreen.getChildren().setAll(newAppointmentScreen);
    }
    @FXML private Text actionTargetReports;

    @FXML protected void handleReportsButtonAction(ActionEvent event) throws IOException {
        GridPane newReportScreen = FXMLLoader.load(getClass().getResource("reportScreen.fxml"));
        mainScreen.getChildren().setAll(newReportScreen);
    }

    @FXML private DatePicker appointmentDateFilter = new DatePicker();

    @FXML protected void handleWeekButtonAction(ActionEvent event){
                DayOfWeek day = appointmentDateFilter.getValue().getDayOfWeek();
                LocalDate selectedDay = appointmentDateFilter.getValue();

                LocalDate startDay = selectedDay.minusDays(0);
                LocalDate endDay = selectedDay.plusDays(7);

                switch(day){
                    case MONDAY:
                         startDay = selectedDay.minusDays(0);
                         endDay = selectedDay.plusDays(6);
                        System.out.println("Monday");
                        break;
                    case TUESDAY:
                        startDay = selectedDay.minusDays(1);
                        endDay = selectedDay.plusDays(5);
                        System.out.println("Tuesday");
                        break;
                    case WEDNESDAY:
                        startDay = selectedDay.minusDays(2);
                        endDay = selectedDay.plusDays(4);
                        System.out.println("Wednesday");
                        break;
                    case THURSDAY:
                        startDay = selectedDay.minusDays(3);
                        endDay = selectedDay.plusDays(3);
                        System.out.println("Thursday");
                        break;
                    case FRIDAY:
                        startDay = selectedDay.minusDays(4);
                        endDay = selectedDay.plusDays(2);
                        System.out.println("Friday");
                        break;
                    case SATURDAY:
                        startDay = selectedDay.minusDays(5);
                        endDay = selectedDay.plusDays(1);
                        System.out.println("Saturday");
                        break;
                    case SUNDAY:
                        startDay = selectedDay.minusDays(6);
                        endDay = selectedDay.plusDays(0);
                        System.out.println("Sunday");
                        break;
                }


        LocalDate finalStartDay = startDay;
        LocalDate finalEndDay = endDay;
        System.out.println(startDay + " : "+ finalStartDay);
        System.out.println(endDay + " : "+ finalEndDay);
        FilteredList<Appointment> filterWeek = new FilteredList<Appointment>(appointmentList, (a->
                    a.getAppointmentStart().toLocalDateTime().toLocalDate().isAfter(finalStartDay) && a.getAppointmentStart().toLocalDateTime().toLocalDate().isBefore(finalEndDay)));

        appointmentTable.setItems(FXCollections.observableList((filterWeek)));

    }




    @FXML protected void handleAllButtonAction(ActionEvent event){
        appointmentTable.setItems(appointmentList);
    }

    @FXML private Text actionTargetViewCustomer;

    @FXML protected void handleDeleteAppButtonAction(ActionEvent event){
       Integer appId =  appointmentTable.getSelectionModel().getSelectedItem().getAppointmentId();

        Query.makeQuery("DELETE FROM `appointment` WHERE appointmentId = "+appId+";");

        appointmentTable.getSelectionModel().clearSelection();
        appointmentTable.getItems().clear();

        try{ appointmentList.addAll(AppointmentDaoImpl.getAllAppointments());
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
        appointmentTable.setItems(appointmentList);
    }

    //Table View Data

    @FXML private TableView<Appointment> appointmentTable;
    @FXML private TableColumn<Appointment, String> colServiceAgent;
    @FXML private TableColumn<Appointment, String> colCustomerName;
    @FXML private TableColumn<Appointment, String> colStartTime;
    @FXML private TableColumn<Appointment, String> colEndTime;
    @FXML private TableColumn<Appointment, String> colAppType;


    ObservableList<Appointment> appointmentList =
            FXCollections.observableArrayList();
    //Filters
    @FXML private ComboBox<Month> selectMonthComboBox;

    ObservableList<Month> monthList =
            FXCollections.observableArrayList(Month.JANUARY, Month.FEBRUARY,Month.MARCH,
                    Month.APRIL, Month.MAY, Month.JUNE, Month.JULY, Month.AUGUST,
                    Month.SEPTEMBER, Month.OCTOBER, Month.NOVEMBER,Month.DECEMBER);


    //Appointment Fields
    @FXML private Label selectedAppText;
    @FXML private DatePicker appointmentDate;
    @FXML private ComboBox<String> appStartHourComboBox;
    @FXML private ComboBox<String> appStartMinComboBox;
    @FXML private ComboBox<String> appEndHourComboBox;
    @FXML private ComboBox<String> appEndMinComboBox;

    @FXML private ComboBox<String> appTypeComboBox;

    ObservableList<String> appStartHrList =
            FXCollections.observableArrayList();

    ObservableList<String> appStartMinList =
            FXCollections.observableArrayList();

    ObservableList<String> appEndHrList =
            FXCollections.observableArrayList();

    ObservableList<String> appEndMinList =
            FXCollections.observableArrayList();

    ObservableList<String> appTypeList =
            FXCollections.observableArrayList("Presentation", "Scrum", "Stand Up");

    @FXML protected void handleUpdateAppointmentAction(ActionEvent event) throws SQLException {
//        Integer id = appointmentTable.getSelectionModel().getSelectedItem().getAppointmentId();
        if(appointmentDate.getValue() == null || appStartHourComboBox.getValue() == null
                || appStartMinComboBox.getValue() ==null || appTypeComboBox.getValue() == null){

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Missing Values");
            alert.setContentText("Must select a customer, date, and time to create a new appointment.");
            alert.setGraphic(null);
            alert.showAndWait();
        }
        else {
            try {
                //Get Customer Data
                Integer appId = appointmentTable.getSelectionModel().getSelectedItem().getAppointmentId();

                // Get appointment date and time selection
                LocalDate date = appointmentDate.getValue();
                String appStartHr = appStartHourComboBox.getValue();
                String appStartMin = appStartMinComboBox.getValue();
                String appEndHr = appEndHourComboBox.getValue();
                String appEndMin = appEndMinComboBox.getValue();
                String appType = appTypeComboBox.getValue();


                //Get Local Date Time
                LocalDateTime ldtStart = LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), Integer.parseInt(appStartHr), Integer.parseInt(appStartMin));
                LocalDateTime ldtEnd = LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), Integer.parseInt(appEndHr), Integer.parseInt(appEndMin));
                //Adding Local Zone
                ZonedDateTime sZdt = ldtStart.atZone(ZoneId.systemDefault());
                ZonedDateTime eZdt = ldtEnd.atZone(ZoneId.systemDefault());

                //Changing to UTC ZONe
                ZonedDateTime sUtc = sZdt.withZoneSameInstant(ZoneId.of("UTC"));
                ZonedDateTime eUtc = eZdt.withZoneSameInstant(ZoneId.of("UTC"));
                //Changing to Database Type
                LocalDateTime fldtStart = sUtc.toLocalDateTime();
                LocalDateTime fldtEnd = eUtc.toLocalDateTime();

                User currentUser = new User();


                Integer userId = currentUser.getUserId();
                //Appointment overlap check for customer and client, better approach but assement wants no overlaps at all
                //Query.makeQuery("SELECT * FROM appointment WHERE (userId = " + userId + " AND appointmentId != " + appId + ") AND appointment.start BETWEEN '" + fldtStart + "' AND '" + fldtEnd + "' ;");
                Query.makeQuery("SELECT * FROM appointment WHERE '" + fldtStart + "' BETWEEN start AND end OR '" + fldtEnd + "' BETWEEN start AND end;");
                ResultSet result = Query.getResult();
                if (result.next()) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Appointment Overlap");
                    alert.setContentText("The appointment you are trying to schedule overlaps with an existing appointment. Please change the appointment time.");
                    alert.setGraphic(null);
                    alert.showAndWait();
                } else {
                    Query.makeQuery("UPDATE `appointment` SET userId = " + userId + ", type = '" + appType + "', start = '" + fldtStart + "', end = '" + fldtEnd + "' WHERE appointmentId = " + appId + ";");

                    appointmentDate.getEditor().clear();
                    appStartHourComboBox.getSelectionModel().clearSelection();
                    appStartMinComboBox.getSelectionModel().clearSelection();
                    appEndHourComboBox.getSelectionModel().clearSelection();
                    appEndMinComboBox.getSelectionModel().clearSelection();
                    appTypeComboBox.getSelectionModel().clearSelection();

                    appointmentTable.getSelectionModel().clearSelection();
                    appointmentTable.getItems().clear();

                    try {
                        appointmentList.addAll(AppointmentDaoImpl.getAllAppointments());
                    } catch (Exception ex) {
                        Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    appointmentTable.setItems(appointmentList);
                }

        }
            catch(Exception ex) {
                System.out.println(ex);
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No Appointment Selected");
                alert.setHeaderText("Select an appointment to update");
                alert.setContentText("You must select an appointment from the calendar above to make an update. ");
                alert.setGraphic(null);
                alert.showAndWait();
            }
        }

    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        //Lambda expressions to efficiently populate Table View
        colCustomerName.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getCustomerName());
        });
        colServiceAgent.setCellValueFactory(cellData ->{
            return new ReadOnlyStringWrapper(cellData.getValue().getServiceAgent());
        });

        colStartTime.setCellValueFactory(cellData -> {
            return new ReadOnlyObjectWrapper(cellData.getValue().getAppointmentStart());
        });
        colEndTime.setCellValueFactory(cellData ->{
            return new ReadOnlyObjectWrapper(cellData.getValue().getAppointmentEnd());
        });

        colAppType.setCellValueFactory(cellData ->{
            return new ReadOnlyStringWrapper(cellData.getValue().getAppointmentType());
        });

        try{ appointmentList.addAll(AppointmentDaoImpl.getAllAppointments());
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }

        appointmentTable.setItems(appointmentList);

        //Lambda expression to efficiently add listeners to all cells of the TableView
        appointmentTable.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends Appointment> observable, Appointment oldValue, Appointment newValue) -> {
            if (newValue != null) {

                String customer = appointmentTable.getSelectionModel().getSelectedItem().getCustomerName();
                ZonedDateTime appStart = appointmentTable.getSelectionModel().getSelectedItem().getAppointmentStart();
                ZonedDateTime appEnd = appointmentTable.getSelectionModel().getSelectedItem().getAppointmentEnd();
                String appType = appointmentTable.getSelectionModel().getSelectedItem().getAppointmentType();

                selectedAppText.setText("Customer: "+customer+" Appointment Start: "+appStart+" Appointment End: "+appEnd+" Appointment Type: "+appType+".");


                System.out.println(appStart);
            }
        });

        selectMonthComboBox.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends Month> observable, Month oldvalue, Month newValue)->{
            if(newValue != null){
                Month thisMonth = selectMonthComboBox.getValue();

                FilteredList<Appointment> filteredMonth = new FilteredList<Appointment>(appointmentList, (a->
                        a.getAppointmentStart().toLocalDateTime().getMonth().equals(thisMonth)));

                appointmentTable.setItems(FXCollections.observableList((filteredMonth)));
            }
        });

        appStartHrList.addAll("08", "09", "10", "11", "12", "13",
                "14", "15", "16");
        appStartMinList.addAll("00", "15", "30", "45");

        appStartHourComboBox.setItems(appStartHrList);
        appStartMinComboBox.setItems(appStartMinList);

        appEndHrList.addAll("08", "09", "10", "11", "12", "13",
                "14", "15", "16");
        appEndMinList.addAll("00", "15", "30", "45");

        appEndHourComboBox.setItems(appEndHrList);
        appEndMinComboBox.setItems(appEndMinList);
        appTypeComboBox.setItems(appTypeList);
        selectMonthComboBox.setItems(monthList);



    }
}


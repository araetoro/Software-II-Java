package application;

import DAO.Query;
import DAO.UserDaoImpl;
import com.sun.org.apache.xpath.internal.operations.Bool;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.InputMethodTextRun;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Window;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ResourceBundle;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Locale;
import java.util.logging.SimpleFormatter;

import javafx.application.Application.Parameters;

public class LoginController implements Initializable {

    @FXML private TextField uNameField;
    @FXML private PasswordField passField;


    @FXML GridPane loginPane;

    @FXML protected void handleSubmitButtonAction(ActionEvent event) throws IOException {

        String uName = uNameField.getText();
        String pass = passField.getText();

        Integer i = 0;

        Boolean runLoop = false;
        try {
            while (runLoop == false) {
                if (usersList.get(i).getUserName().contentEquals(uName) && usersList.get(i).getPassword().contentEquals(pass)) {
                    Integer userId = usersList.get(i).getUserId();
                    Timestamp now = new Timestamp(System.currentTimeMillis());
                    LocalDateTime plusNow = now.toLocalDateTime().plusMinutes(15);
                    ObservableList<ZonedDateTime>
                            allAppointments= FXCollections.observableArrayList();

                    Query.makeQuery("SELECT * FROM appointment WHERE userId ="+userId+" AND start <= '"+plusNow+"' AND start >= '"+now+"';");
                    ResultSet result = Query.getResult();

                    while(result.next()){

                        Timestamp appStart = result.getTimestamp("start");

                        //change to local time
                        LocalDateTime sLdt =  appStart.toLocalDateTime();
                        ZonedDateTime sZdt = sLdt.atZone(ZoneId.systemDefault());

                        allAppointments.add(sZdt);
                    }
                    System.out.println(allAppointments);
                    if (!allAppointments.isEmpty()){
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Upcoming Appointment");
                        alert.setHeaderText("15min Warning");
                        alert.setContentText("You have an Appointment Starting with in 15mins.");
                        alert.setGraphic(null);
                        alert.showAndWait();
                        runLoop = true;
                    }


                    GridPane mainScreen = FXMLLoader.load(getClass().getResource("mainScreen.fxml"));
                    loginPane.getChildren().setAll(mainScreen);

                    //Logging user activity
                    Logger log = Logger.getLogger("log.text");

                        try {
                            FileHandler fh = null;
                            try {
                                fh = new FileHandler("log.txt", true);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            SimpleFormatter sf = new SimpleFormatter();
                            fh.setFormatter(sf);
                            log.addHandler(fh);
                            Timestamp loginTime = new Timestamp(System.currentTimeMillis());

                            log.info("User: " +uName + " Login Time: "+loginTime);
                            //log.log(Level.INFO, "" + uName);

                        } catch (SecurityException ex) {
                            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
                        }

                    runLoop = true;
                }
                //Error with sign in Alert
                else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Sign in Error");
                    alert.setContentText("User Name and password do not match.");
                    alert.setGraphic(null);
                    alert.showAndWait();
                    runLoop = true;
                }
            }
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    ObservableList<User> usersList =
            FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        try{ usersList.addAll(UserDaoImpl.getAllUsers());
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

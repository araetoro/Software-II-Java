package application;

import DAO.UserDaoImpl;
import com.sun.org.apache.xpath.internal.operations.Bool;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Window;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Locale;

import javafx.application.Application.Parameters;

public class LoginController implements Initializable {

    @FXML private TextField uNameField;
    @FXML private PasswordField passField;
    @FXML private Button loginButton;

    @FXML GridPane loginPane;

    @FXML protected void handleSubmitButtonAction(ActionEvent event) throws IOException {

        String uName = uNameField.getText();
        String pass = passField.getText();
        Integer i = 0;

        Boolean runLoop = false;
        try {
            while (runLoop == false) {
                if (usersList.get(i).getUserName().contentEquals(uName) && usersList.get(i).getPassword().contentEquals(pass)) {
                    System.out.println("3. " + uName + ": " + pass);

                    GridPane mainScreen = FXMLLoader.load(getClass().getResource("mainScreen.fxml"));
                    loginPane.getChildren().setAll(mainScreen);

                    runLoop = true;
                } else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Sign in Error");
                    alert.setContentText("User Name and password do not match.");
                    alert.setGraphic(null);
                    alert.showAndWait();
                    runLoop = true;
                }
            }
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    ObservableList<User> usersList =
            FXCollections.observableArrayList();

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        try{ usersList.addAll(UserDaoImpl.getAllUsers());
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

package application;

import DAO.Query;
import DAO.UserDaoImpl;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.Locale;
import java.util.logging.SimpleFormatter;

public class LoginController implements Initializable {
    //Get Users Location
    Locale locale = Locale.getDefault();
    ResourceBundle rb = ResourceBundle.getBundle("ResourceBundle/rb", locale);


    @FXML private TextField uNameField;
    @FXML private PasswordField passField;
    @FXML Button loginButton;
    @FXML Text welcomeLabel;
    @FXML Label userNameLabel;
    @FXML Label passwordLabel;



    @FXML GridPane loginPane;

    @FXML protected void handleSubmitButtonAction(ActionEvent event) throws IOException, SQLException {


        String uName = uNameField.getText();
        String pass = passField.getText();

        if(userPass.get(uName) != null && userPass.get(uName).equals(pass)){
            Integer userId =  useNameId.get(uName);
            User currentUser = new User(uName,pass,userId);

            Timestamp now = new Timestamp(System.currentTimeMillis());
            LocalDateTime ldtStart = now.toLocalDateTime();

            //Adding Local Zone
            ZonedDateTime sZdt = ldtStart.atZone(ZoneId.systemDefault());

            //Changing to UTC ZONe
            ZonedDateTime sUtc = sZdt.withZoneSameInstant(ZoneId.of("UTC"));
            //Changing to Database Type
            LocalDateTime fldtStart = sUtc.toLocalDateTime();

            LocalDateTime plusNow = fldtStart.plusMinutes(15);
            ObservableList<ZonedDateTime>
                    allAppointments= FXCollections.observableArrayList();

            Query.makeQuery("SELECT * FROM appointment WHERE userId ="+userId+" AND start <= '"+plusNow+"' AND start >= '"+fldtStart+"';");
            ResultSet result = Query.getResult();

            while(result.next()){

                Timestamp appStart = result.getTimestamp("start");

                //change to local time
                LocalDateTime sLdt =  appStart.toLocalDateTime();
                ZonedDateTime startZdt = sLdt.atZone(ZoneId.systemDefault());

                allAppointments.add(startZdt);
            }
            System.out.println(allAppointments);
            if (!allAppointments.isEmpty()){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Upcoming Appointment");
                alert.setHeaderText("15min Warning");
                alert.setContentText("You have an Appointment Starting with in 15mins.");
                alert.setGraphic(null);
                alert.showAndWait();
            }


            GridPane mainScreen = FXMLLoader.load(getClass().getResource("mainScreen.fxml"));
            loginPane.getChildren().setAll(mainScreen);

            //Logging user activity
            Logger log = Logger.getLogger("log.text");

            try {
                FileHandler fh = null;
                try {
                    fh = new FileHandler("log.txt", true);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                SimpleFormatter sf = new SimpleFormatter();
                fh.setFormatter(sf);
                log.addHandler(fh);
                Timestamp loginTime = new Timestamp(System.currentTimeMillis());

                log.info("User: " +uName + " Login Time: "+loginTime);
                //log.log(Level.INFO, "" + uName);

            } catch (SecurityException ex) {
                Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
            }

        }





//        try {
//            while (i< userNum) {
//                System.out.println(usersList.get(i).getUserName());
//                System.out.println(usersList.get(i).getPassword());
//                if (usersList.get(i).getUserName().contentEquals(uName) && usersList.get(i).getPassword().contentEquals(pass)) {
//                    Integer userId = usersList.get(i).getUserId();
//                    Timestamp now = new Timestamp(System.currentTimeMillis());
//                    LocalDateTime plusNow = now.toLocalDateTime().plusMinutes(15);
//                    ObservableList<ZonedDateTime>
//                            allAppointments= FXCollections.observableArrayList();
//
//                    Query.makeQuery("SELECT * FROM appointment WHERE userId ="+userId+" AND start <= '"+plusNow+"' AND start >= '"+now+"';");
//                    ResultSet result = Query.getResult();
//
//                    while(result.next()){
//
//                        Timestamp appStart = result.getTimestamp("start");
//
//                        //change to local time
//                        LocalDateTime sLdt =  appStart.toLocalDateTime();
//                        ZonedDateTime sZdt = sLdt.atZone(ZoneId.systemDefault());
//
//                        allAppointments.add(sZdt);
//                    }
//                    System.out.println(allAppointments);
//                    if (!allAppointments.isEmpty()){
//                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
//                        alert.setTitle("Upcoming Appointment");
//                        alert.setHeaderText("15min Warning");
//                        alert.setContentText("You have an Appointment Starting with in 15mins.");
//                        alert.setGraphic(null);
//                        alert.showAndWait();
//                    }
//
//
//                    GridPane mainScreen = FXMLLoader.load(getClass().getResource("mainScreen.fxml"));
//                    loginPane.getChildren().setAll(mainScreen);
//
//                    //Logging user activity
//                    Logger log = Logger.getLogger("log.text");
//
//                        try {
//                            FileHandler fh = null;
//                            try {
//                                fh = new FileHandler("log.txt", true);
//                            } catch (IOException e) {
//                                e.printStackTrace();
//                            }
//                            SimpleFormatter sf = new SimpleFormatter();
//                            fh.setFormatter(sf);
//                            log.addHandler(fh);
//                            Timestamp loginTime = new Timestamp(System.currentTimeMillis());
//
//                            log.info("User: " +uName + " Login Time: "+loginTime);
//                            //log.log(Level.INFO, "" + uName);
//
//                        } catch (SecurityException ex) {
//                            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
//                        }


//
//                }
                //Error with sign in Alert
                else {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle(rb.getString("error"));
                    alert.setHeaderText(rb.getString( "signIn"));
                    alert.setContentText(rb.getString("user"));
                    alert.setGraphic(null);
                    alert.showAndWait();
                }
//            }
    }
//        catch (Exception ex){
//            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }

    ObservableList<User> usersList =
            FXCollections.observableArrayList();

    HashMap<String, String> userPass = new HashMap<>();

    HashMap<String, Integer> useNameId = new HashMap<>();

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        loginButton.setText(rb.getString("buttonText"));
        welcomeLabel.setText(rb.getString("welcome"));
        userNameLabel.setText(rb.getString("userName"));
        passwordLabel.setText(rb.getString("password"));

        try{ usersList.addAll(UserDaoImpl.getAllUsers());
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }

        try{ userPass.putAll(UserDaoImpl.getUserPass());
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
        try{ useNameId.putAll(UserDaoImpl.getUserIdHas());
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}

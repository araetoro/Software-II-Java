package application;

import DAO.DBConnection;
import DAO.Query;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

import java.io.IOException;

import DAO.CustomerDaoImpl;

public class NewCustomerController {

    @FXML private TextField cNameField;
    @FXML private TextField addressField;
    @FXML private TextField cityField;
    @FXML private TextField countryField;
    @FXML private TextField phoneField;

    @FXML GridPane newCustomerScreen;

    @FXML protected void handleBackButtonAction(ActionEvent event)throws IOException{
        GridPane customerScreen = FXMLLoader.load(getClass().getResource("CustomerScreen.fxml"));
        newCustomerScreen.getChildren().setAll(customerScreen);

    }


    @FXML protected void handleAddCustomerButtonAction(ActionEvent event) throws Exception {
        String customerName = cNameField.getText();
        String address = addressField.getText();
        String city = cityField.getText();
        String country = countryField.getText();
        String phone = phoneField.getText();
        Integer id = CustomerDaoImpl.getNextId();

        System.out.println(customerName +" " + address+ " "+ " "+ city+ " " + country + " " + phone+ " " +id );

        Query.makeQuery("INSERT INTO `country` VALUES ("+ id + ", '" +country+ "', NOW(),'test', NOW(), 'test');");
        Query.makeQuery("INSERT INTO `city` VALUES ("+ id +",'"+ city +"',"+ id +",NOW(),'test',NOW(),'test');");
        Query.makeQuery("INSERT INTO `address` VALUES ("+ id +",'"+address+"','',"+ id +",'null','"+ phone +"', NOW(),'test', NOW(),'test');");
        Query.makeQuery("INSERT INTO `customer` VALUES ("+ id +",'"+ customerName +"',"+ id +",1,NOW(),'test',NOW(),'test');");

        GridPane customerScreen = FXMLLoader.load(getClass().getResource("CustomerScreen.fxml"));
        newCustomerScreen.getChildren().setAll(customerScreen);

    }
}

package application;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import sun.java2d.pipe.SpanShapeRenderer;

import javax.lang.model.util.SimpleElementVisitor6;

public class Customer {
    private Integer customerId = new Integer(0);
    private String customerName = new String("");
    private String address = new String("");
    private String city = new String("");
    private String country = new String("");
    private String phone = new String("");


    public Customer(){
        this(0,"", "", "", "", "");
    }

    public Customer(Integer cId, String cName, String addr, String c, String n, String p){
        customerId = cId;
        customerName = cName;
        address = addr;
        city = c;
        country = n;
        phone = p;

    }

    public Integer getCustomerId(){

        return customerId;
    }

    public void setCustomerId(Integer cId){

        customerId = cId;
    }


    public String getCustomerName(){

        return customerName;
    }

    public void setCustomerName(String cName){

        customerName = cName;
    }

    public String getAddress(){
        return address;}

    public void setAddress(String addr){
        address = addr;}

    public String getCity(){
        return city;
    }

    public void setCity(String c){
        city = c;
    }

    public String getCountry(){
        return country;
    }

    public void setCountry(String n){
        country = n;
    }

    public String getPhone(){
        return phone;
    }

    public void setPhone(String p){
        phone = p;
    }

}

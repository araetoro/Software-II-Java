package application;

import DAO.CustomerDaoImpl;
import DAO.Query;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;

import java.io.IOException;
import java.net.URL;
import java.time.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class NewAppointmentScreenController implements Initializable {

    @FXML private TableView<Customer> CustomerTable;
    @FXML private TableColumn<Customer, String> colCustomerName;
    @FXML private TableColumn<Customer, String> colAddress;
    @FXML private TableColumn<Customer, String> colCity;
    @FXML private TableColumn<Customer, String> colCountry;
    @FXML private TableColumn<Customer, String> colPhone;


    @FXML GridPane customerScreen;

    @FXML protected void handleAppointmentsButtonAction(ActionEvent event) throws IOException {
        GridPane mainScreen = FXMLLoader.load(getClass().getResource("mainScreen.fxml"));
        customerScreen.getChildren().setAll(mainScreen);
    }

    //Appointment Fields
    @FXML private DatePicker appointmentDate;
    @FXML private ComboBox<String> appStartHourComboBox;
    @FXML private ComboBox<String> appStartMinComboBox;
    @FXML private ComboBox<String> appEndHourComboBox;
    @FXML private ComboBox<String> appEndMinComboBox;

    @FXML private ComboBox<String> appTypeComboBox;

    ObservableList<String> appStartHrList =
            FXCollections.observableArrayList();

    ObservableList<String> appStartMinList =
            FXCollections.observableArrayList();

    ObservableList<String> appEndHrList =
            FXCollections.observableArrayList();

    ObservableList<String> appEndMinList =
            FXCollections.observableArrayList();

    ObservableList<String> appTypeList =
            FXCollections.observableArrayList("Presentation", "Scrum", "Stand Up");

    @FXML private TextField cNameField;
    @FXML private TextField addressField;
    @FXML private TextField cityField;
    @FXML private TextField countryField;
    @FXML private TextField phoneField;




    @FXML private void handleAddAppointmentButtonAction(ActionEvent event) throws Exception {
        if(!cNameField.getText().isEmpty() && appointmentDate.getValue()!=null && appStartHourComboBox.getValue() != null
                && appStartMinComboBox.getValue() !=null && appTypeComboBox.getValue() != null) {

            //Get Customer Data
            Integer id = CustomerTable.getSelectionModel().getSelectedItem().getCustomerId();


            // Get appointment date and time selection
            LocalDate date = appointmentDate.getValue();
            String appStartHr = appStartHourComboBox.getValue();
            String appStartMin = appStartMinComboBox.getValue();
            String appEndHr = appEndHourComboBox.getValue();
            String appEndMin = appEndMinComboBox.getValue();
            String appType = appTypeComboBox.getValue();


            //Get Local Date Time
            LocalDateTime ldtStart = LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), Integer.parseInt(appStartHr), Integer.parseInt(appStartMin));
            LocalDateTime ldtEnd = LocalDateTime.of(date.getYear(), date.getMonth(), date.getDayOfMonth(), Integer.parseInt(appEndHr), Integer.parseInt(appEndMin));
            //Adding Local Zone
            ZonedDateTime sZdt = ldtStart.atZone(ZoneId.systemDefault());
            ZonedDateTime eZdt = ldtEnd.atZone(ZoneId.systemDefault());

            //Changing to UTC ZONe
            ZonedDateTime sUtc = sZdt.withZoneSameInstant(ZoneId.of("UTC"));
            ZonedDateTime eUtc = eZdt.withZoneSameInstant(ZoneId.of("UTC"));
            //Changing to Database Type
            LocalDateTime fldtStart = sUtc.toLocalDateTime();
            LocalDateTime fldtEnd = eUtc.toLocalDateTime();

            int appId = DAO.AppointmentDaoImpl.getNextId();

            Query.makeQuery("");
            Query.makeQuery("INSERT INTO `appointment` VALUES ("+appId+","+id+",1,'not needed','not needed','not needed','not needed', '"+appType+"','not needed', '"+fldtStart+"', '"+fldtEnd+"', NOW(), 'test', NOW(),'test');");

            cNameField.clear();
            addressField.clear();
            phoneField.clear();
            cityField.clear();
            countryField.clear();

            appointmentDate.getEditor().clear();
            appStartHourComboBox.getSelectionModel().clearSelection();
            appStartMinComboBox.getSelectionModel().clearSelection();
            appEndHourComboBox.getSelectionModel().clearSelection();
            appEndMinComboBox.getSelectionModel().clearSelection();
            appTypeComboBox.getSelectionModel().clearSelection();

        }
        else{

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText("Missing Values");
            alert.setContentText("Must select a customer, date, & time to create new appointment.");
            alert.setGraphic(null);
            alert.showAndWait();
        }

    }

    @FXML private void handleClearButtonAction(ActionEvent event){
        cNameField.clear();
        addressField.clear();
        cityField.clear();
        countryField.clear();
        phoneField.clear();

    }

    //For Customer Table
    ObservableList<Customer> customerList =
            FXCollections.observableArrayList();


    @Override
    public void initialize(URL location, ResourceBundle resources) {

        colCustomerName.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getCustomerName());
        });
        colAddress.setCellValueFactory(cellData ->{
            return new ReadOnlyStringWrapper(cellData.getValue().getAddress());
        });

        colCity.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getCity());
        });
        colCountry.setCellValueFactory(cellData ->{
            return new ReadOnlyStringWrapper(cellData.getValue().getCountry());
        });

        colPhone.setCellValueFactory(cellData ->{
            return new ReadOnlyStringWrapper(cellData.getValue().getPhone());
        });

        try{ customerList.addAll(CustomerDaoImpl.getAllCustomers());
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
        CustomerTable.setItems(customerList);

        CustomerTable.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends Customer> observable, Customer oldValue, Customer newValue) -> {
            if (newValue != null) {
                String customerName = CustomerTable.getSelectionModel().getSelectedItem().getCustomerName();
                cNameField.setText(customerName);

                String address = CustomerTable.getSelectionModel().getSelectedItem().getAddress();
                addressField.setText(address);

                String city = CustomerTable.getSelectionModel().getSelectedItem().getCity();
                cityField.setText(city);

                String country = CustomerTable.getSelectionModel().getSelectedItem().getCountry();
                countryField.setText(country);

                String phone = CustomerTable.getSelectionModel().getSelectedItem().getPhone();
                phoneField.setText(phone);
            }
        });

        //Combo Box App Time
//        appStartList.addAll("08", "08:30", "09", "09:30", "10", "10:30", "11", "11:30", "12", "12:30", "13",
//                "13:30", "14", "14:30", "15","15:30", "16","16:30");
        appStartHrList.addAll("08", "09", "10", "11", "12", "13",
                "14", "15", "16");
        appStartMinList.addAll("00", "15", "30", "45");

        appStartHourComboBox.setItems(appStartHrList);
        appStartMinComboBox.setItems(appStartMinList);

        appEndHrList.addAll("08", "09", "10", "11", "12", "13",
                "14", "15", "16");
        appEndMinList.addAll("00", "15", "30", "45");

        appEndHourComboBox.setItems(appEndHrList);
        appEndMinComboBox.setItems(appEndMinList);
//        durationComboBox.setConverter(new StringConverter<Customer>() {
//            @Override
//            public String toString(Customer object) {
//                return object.getCustomerName();
//            }
//
//            @Override
//            public Customer fromString(String string) {
//                return durationComboBox.getItems().stream().filter( ap ->
//                        ap.getCustomerName().equals(string)).findFirst().orElse(null);
//            };
//        });
//        customerComboBox.valueProperty().addListener((obs, oldval, newval)->{
//            if(newval!=null)
//                customerId = newval.getCustomerId();
//            System.out.println(newval.getCustomerName() + " Customer Id: "+ customerId);
//        });

        //Combo Box App Duration

//        durationComboBox.setConverter(new StringConverter<Customer>() {
//            @Override
//            public String toString(Customer object) {
//                return object.getCustomerName();
//            }
//
//            @Override
//            public Customer fromString(String string) {
//                return durationComboBox.getItems().stream().filter( ap ->
//                        ap.getCustomerName().equals(string)).findFirst().orElse(null);
//            };
//        });
//        customerComboBox.valueProperty().addListener((obs, oldval, newval)->{
//            if(newval!=null)
//                customerId = newval.getCustomerId();
//            System.out.println(newval.getCustomerName() + " Customer Id: "+ customerId);
//        });


        //Combo Box Type
        appTypeComboBox.setItems(appTypeList);
//        durationComboBox.setConverter(new StringConverter<Customer>() {
//            @Override
//            public String toString(Customer object) {
//                return object.getCustomerName();
//            }
//
//            @Override
//            public Customer fromString(String string) {
//                return durationComboBox.getItems().stream().filter( ap ->
//                        ap.getCustomerName().equals(string)).findFirst().orElse(null);
//            };
//        });
//        customerComboBox.valueProperty().addListener((obs, oldval, newval)->{
//            if(newval!=null)
//                customerId = newval.getCustomerId();
//            System.out.println(newval.getCustomerName() + " Customer Id: "+ customerId);
//        });

        }
}
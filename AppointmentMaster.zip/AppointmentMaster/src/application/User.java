package application;

import javafx.beans.property.SimpleStringProperty;

public class User {
    private static String userName = new String("");
    private static String password = new String("");
    private static Integer userId = new Integer(0);

    public User(){
        userName = userName;
        password = password;
        userId = userId;}

    public User(String uName, String pass, Integer id) {
        userName = uName;
        password = pass;
        userId = id;
    }
    public User(String uName, String pass) {
        userName = uName;
        password = pass;
    }
    public User(String uName, Integer id) {
        userName = uName;
        userId = id;
    }

    public String getUserName(){

        return userName;
    }

    public void setUserName(String uName){
        userName = uName;
    }

    public String getPassword(){
        return password;}

    public void setPassword(String pass){
        password = pass;}

    public Integer getUserId(){
        return userId;}

    public void setUserId(Integer id){
        userId = id;}

}

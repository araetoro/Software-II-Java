package application;

import javafx.beans.property.SimpleStringProperty;

public class User {
    private static String userName = new String("");
    private static String password = new String("");

    public User(){
        this("", "");
        }

    public User(String uName, String pass) {
        userName = uName;
        password = pass;
    }
    public String getUserName(){

        return userName;
    }

    public void setUserName(String uName){
        userName = uName;
    }

    public String getPassword(){
        return password;}

    public void setPassword(String pass){
        password = pass;}
}

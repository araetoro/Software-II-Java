package application;

import DAO.ReportDaoImpl;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.GridPane;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ReportScreenController implements Initializable {

    @FXML
    GridPane customerScreen;

    @FXML protected void handleAppointmentsButtonAction(ActionEvent event) throws IOException {
        GridPane mainScreen = FXMLLoader.load(getClass().getResource("mainScreen.fxml"));
        customerScreen.getChildren().setAll(mainScreen);
    }



    @FXML private TableView<Report> ReportTable;
    @FXML private TableColumn<Report, String> colOne;
    @FXML private TableColumn<Report, String> colTwo;
    @FXML private TableColumn<Report, String> colThree;


    //For Reports Table
    ObservableList<Report> reportList =
            FXCollections.observableArrayList();

    @FXML protected void handlePresentationButtonAction(ActionEvent event){
        colOne.setText("Appointment Type: ");
        colTwo.setText("Count: ");
        colTwo.setText("");
        ReportTable.setItems(reportList);
        colOne.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getAppointmentType());
        });
        colTwo.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getCount());
        });
        colThree.setCellValueFactory(cellData -> {
            return new ReadOnlyObjectWrapper(null);
        });

    }

    ObservableList<Report> userReportList =
            FXCollections.observableArrayList();


    @FXML protected void handleConsultantButtonAction(ActionEvent event){
        colOne.setText("Consultant: ");
        colTwo.setText("Appointment Time:");
        colTwo.setText("");
        ReportTable.setItems(userReportList);
        colOne.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getServiceAgent());
        });
        colTwo.setCellValueFactory(cellData -> {
            return new ReadOnlyObjectWrapper(cellData.getValue().getAppointmentStart());
        });
        colThree.setCellValueFactory(cellData -> {
            return new ReadOnlyObjectWrapper(null);
        });
    }

    ObservableList<Report> reportListUserType =
            FXCollections.observableArrayList();

    @FXML protected void handleUserTypeButtonAction(ActionEvent event){
        colOne.setText("Consultant: ");
        colTwo.setText("Appointment Type: ");
        colThree.setText("Count");
        ReportTable.setItems(reportListUserType);
        colOne.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getServiceAgent());
        });
        colTwo.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getAppointmentType());
        });
        colThree.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getCount());
        });

    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {

//        colType.setCellValueFactory(cellData -> {
//            return new ReadOnlyStringWrapper(cellData.getValue());
//        });
//        colCount.setCellValueFactory(cellData -> {
//            return new ReadOnlyStringWrapper(cellData.getValue());
//        });

        try {
            reportList.addAll(ReportDaoImpl.getAppTypes());
        } catch (Exception ex) {
            Logger.getLogger(ReportScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            userReportList.addAll(ReportDaoImpl.getAppByUser());
        } catch (Exception ex) {
            Logger.getLogger(ReportScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {
            reportListUserType.addAll(ReportDaoImpl.getAppTypesByUser());
        } catch (Exception ex) {
            Logger.getLogger(ReportScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }    }
}

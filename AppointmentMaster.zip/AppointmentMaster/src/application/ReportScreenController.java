package application;

import DAO.ReportDaoImpl;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ReportScreenController implements Initializable {

    @FXML
    GridPane customerScreen;

    @FXML protected void handleAppointmentsButtonAction(ActionEvent event) throws IOException {
        GridPane mainScreen = FXMLLoader.load(getClass().getResource("mainScreen.fxml"));
        customerScreen.getChildren().setAll(mainScreen);
    }

    @FXML protected void handleConsultantButtonAction(ActionEvent event){}

//    @FXML private TableView<String> ReportTable;
//    @FXML private TableColumn<String, String> colType;
//    @FXML private TableColumn<String, String> colCount;


    //For Reports Table
    ObservableList<String> reportList =
            FXCollections.observableArrayList();

    @FXML private javafx.scene.text.Text resultsRow1;
    @FXML private javafx.scene.text.Text resultsRow2;
    @FXML private javafx.scene.text.Text resultsRow3;
    @FXML private javafx.scene.text.Text resultsRow4;

    @FXML protected void handlePresentationButtonAction(ActionEvent event){
        resultsRow1.setText("Presentation Type Counts:");
        try {
            resultsRow2.setText(reportList.get(0) + " Count: " + reportList.get(1));
            resultsRow3.setText(reportList.get(2) + " Count: " + reportList.get(3));
            resultsRow4.setText(reportList.get(4) + " Count: " + reportList.get(5));
        }
        catch (IndexOutOfBoundsException exception){
            System.out.println("index out off bounds");
        }
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {

//        colType.setCellValueFactory(cellData -> {
//            return new ReadOnlyStringWrapper(cellData.getValue());
//        });
//        colCount.setCellValueFactory(cellData -> {
//            return new ReadOnlyStringWrapper(cellData.getValue());
//        });

        try {
            reportList.addAll(ReportDaoImpl.getAppTypes());
        } catch (Exception ex) {
            Logger.getLogger(ReportScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
//        ReportTable.setItems(reportList);
        System.out.println(reportList);
        System.out.println(reportList.get(0));
        System.out.println(reportList.get(1));



    }
}

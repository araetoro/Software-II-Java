package application;

import DAO.CustomerDaoImpl;
import DAO.CustomerDaoImpl.*;
import DAO.DBConnection;
import DAO.Query;
import javafx.beans.property.ReadOnlyObjectWrapper;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;

import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CustomerScreenController implements Initializable {

    @FXML private TableView<Customer> CustomerTable;
    @FXML private TableColumn<Customer, String> colCustomerName;
    @FXML private TableColumn<Customer, String> colAddress;
    @FXML private TableColumn<Customer, String> colCity;
    @FXML private TableColumn<Customer, String> colCountry;
    @FXML private TableColumn<Customer, String> colPhone;
    @FXML private TableColumn<Customer, Integer> colCustomerId;


    @FXML GridPane customerScreen;

    @FXML protected void handleAppointmentsButtonAction(ActionEvent event) throws IOException {
        GridPane mainScreen = FXMLLoader.load(getClass().getResource("mainScreen.fxml"));
        customerScreen.getChildren().setAll(mainScreen);
    }

//    @FXML protected void handleAddCustomerButtonAction(ActionEvent event) throws IOException{
//        GridPane newCustomerScreen = FXMLLoader.load(getClass().getResource("newCustomerScreen.fxml"));
//        customerScreen.getChildren().setAll(newCustomerScreen);
//    }


    @FXML protected void handleDeleteCustomerButtonAction(ActionEvent event) throws IOException{
        Integer selcetedIndex= CustomerTable.getSelectionModel().getSelectedIndex();
        Integer customerToRemove = CustomerTable.getSelectionModel().getSelectedItem().getCustomerId();

        Query.makeQuery("DELETE FROM `appointment` WHERE customerId = "+customerToRemove+";");
        Query.makeQuery("DELETE FROM `customer` WHERE customerId = "+customerToRemove+";");
        Query.makeQuery("DELETE FROM `address` WHERE addressId = "+customerToRemove+";");
        Query.makeQuery("DELETE FROM `city` WHERE cityId = "+customerToRemove+";");
        Query.makeQuery("DELETE FROM `country` WHERE countryId = "+customerToRemove+";");

        cNameField.clear();
        addressField.clear();
        cityField.clear();
        countryField.clear();
        phoneField.clear();

        CustomerTable.getSelectionModel().clearSelection();
        CustomerTable.getItems().clear();

        try{ customerList.addAll(CustomerDaoImpl.getAllCustomers());
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
        CustomerTable.setItems(customerList);

    }

    @FXML private TextField cNameField;
    @FXML private TextField addressField;
    @FXML private TextField cityField;
    @FXML private TextField countryField;
    @FXML private TextField phoneField;


    @FXML protected void handleAddCustomerButtonAction(ActionEvent event) throws Exception {
          if(!cNameField.getText().isEmpty() && !addressField.getText().isEmpty() && !cityField.getText().isEmpty() && !countryField.getText().isEmpty() && !phoneField.getText().isEmpty()){

                String customerName = cNameField.getText();
                String address = addressField.getText();
                String city = cityField.getText();
                String country = countryField.getText();
                String phone = phoneField.getText();

                cNameField.clear();
                addressField.clear();
                cityField.clear();
                countryField.clear();
                phoneField.clear();
                Integer id = CustomerDaoImpl.getNextId();

                System.out.println(customerName + " " + address + " " + " " + city + " " + country + " " + phone + " " + id);

                Query.makeQuery("INSERT INTO `country` VALUES (" + id + ", '" + country + "', NOW(),'test', NOW(), 'test');");
                Query.makeQuery("INSERT INTO `city` VALUES (" + id + ",'" + city + "'," + id + ",NOW(),'test',NOW(),'test');");
                Query.makeQuery("INSERT INTO `address` VALUES (" + id + ",'" + address + "',''," + id + ",'null','" + phone + "', NOW(),'test', NOW(),'test');");
                Query.makeQuery("INSERT INTO `customer` VALUES (" + id + ",'" + customerName + "'," + id + ",1,NOW(),'test',NOW(),'test');");

                CustomerTable.getSelectionModel().clearSelection();
                CustomerTable.getItems().clear();

                try {
                    customerList.addAll(CustomerDaoImpl.getAllCustomers());
                } catch (Exception ex) {
                    Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
                }
                CustomerTable.setItems(customerList);
              }
            else{System.out.println("All fields are required");}

    }

    @FXML protected void handleUpdateCustomerButtonAction(ActionEvent event) throws IOException{
        Integer customerToUpdate = CustomerTable.getSelectionModel().getSelectedItem().getCustomerId();
        String customerName = cNameField.getText();
        cNameField.clear();
        String address = addressField.getText();
        addressField.clear();
        String city = cityField.getText();
        cityField.clear();
        String country = countryField.getText();
        countryField.clear();
        String phone = phoneField.getText();
        phoneField.clear();

        Query.makeQuery("UPDATE `customer` SET customerName = '"+customerName+"' WHERE customerId = "+customerToUpdate+";");
        Query.makeQuery("UPDATE `address` SET address = '"+address+"', phone = '"+phone+"' WHERE addressId = "+customerToUpdate+";");
        Query.makeQuery("UPDATE `city` SET city = '"+city+"' WHERE cityId = "+customerToUpdate+";");
        Query.makeQuery("UPDATE `country` SET country = '"+country+"' WHERE countryId = "+customerToUpdate+";");

        CustomerTable.getSelectionModel().clearSelection();
        CustomerTable.getItems().clear();

        try{ customerList.addAll(CustomerDaoImpl.getAllCustomers());
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
        CustomerTable.setItems(customerList);

    }

    @FXML private void handleClearButtonAction(ActionEvent event){
        cNameField.clear();
        addressField.clear();
        cityField.clear();
        countryField.clear();
        phoneField.clear();

    }

    ObservableList<Customer> customerList =
    FXCollections.observableArrayList();


    @Override
    public void initialize(URL location, ResourceBundle resources) {
//        colCustomerId.setCellValueFactory(cellData -> {
//            return new ReadOnlyObjectWrapper<>(cellData.getValue().getCustomerId());
//        });
        colCustomerName.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getCustomerName());
        });
        colAddress.setCellValueFactory(cellData ->{
            return new ReadOnlyStringWrapper(cellData.getValue().getAddress());
        });

        colCity.setCellValueFactory(cellData -> {
            return new ReadOnlyStringWrapper(cellData.getValue().getCity());
        });
        colCountry.setCellValueFactory(cellData ->{
            return new ReadOnlyStringWrapper(cellData.getValue().getCountry());
        });

        colPhone.setCellValueFactory(cellData ->{
            return new ReadOnlyStringWrapper(cellData.getValue().getPhone());
        });

        try{ customerList.addAll(CustomerDaoImpl.getAllCustomers());
        }
        catch (Exception ex){
            Logger.getLogger(CustomerScreenController.class.getName()).log(Level.SEVERE, null, ex);
        }
        CustomerTable.setItems(customerList);

        CustomerTable.getSelectionModel().selectedItemProperty().addListener((ObservableValue<? extends Customer> observable, Customer oldValue, Customer newValue) -> {
            if (newValue != null) {
                String customerName = CustomerTable.getSelectionModel().getSelectedItem().getCustomerName();
                cNameField.setText(customerName);

                String address = CustomerTable.getSelectionModel().getSelectedItem().getAddress();
                addressField.setText(address);

                String city = CustomerTable.getSelectionModel().getSelectedItem().getCity();
                cityField.setText(city);

                String country = CustomerTable.getSelectionModel().getSelectedItem().getCountry();
                countryField.setText(country);

                String phone = CustomerTable.getSelectionModel().getSelectedItem().getPhone();
                phoneField.setText(phone);
        }
        });
    }
}
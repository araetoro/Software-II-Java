package application;

import javafx.beans.property.SimpleStringProperty;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Appointment {
    private String serviceAgent = new String("");
    private String customerName = new String("");
    private ZonedDateTime appointmentStart;
    private ZonedDateTime appointmentEnd;
    private String appointmentType = new String("");
    private Integer appointmentId = new Integer(0);


    public Appointment() {}

    public Appointment(String sAgent, String cName, ZonedDateTime appS, ZonedDateTime appE, String appT, Integer appId) {
        serviceAgent = sAgent;
        customerName = cName;
        appointmentStart = appS;
        appointmentEnd = appE;
        appointmentType = appT;
        appointmentId = appId;


    }

    public String getCustomerName(){

        return customerName;
    }

    public void setCustomerName(String cName){

        customerName = cName;
    }


    public String getServiceAgent(){
        return serviceAgent;
    }

    public void setServiceAgent(String SAgent){
        serviceAgent = SAgent;
    }

    public ZonedDateTime getAppointmentStart(){
        return appointmentStart;
    }

    public void setAppointmentStart(ZonedDateTime appS){appointmentStart = appS;}

    public ZonedDateTime getAppointmentEnd(){
        return appointmentEnd;
    }

    public void setAppointmentEnd(ZonedDateTime appE){
        appointmentEnd = appE;
    }

    public String getAppointmentType(){
        return appointmentType;
    }

    public void setAppointmentType(String appT){
        appointmentType = appT;
    }

    public Integer getAppointmentId(){
        return appointmentId;
    }


}
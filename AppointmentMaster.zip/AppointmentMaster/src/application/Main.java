package application;

import DAO.CustomerDaoImpl;
import DAO.DBConnection;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("login.fxml"));
        primaryStage.setTitle("Welcome To Appointment Master");
        primaryStage.setScene(new Scene(root, 900, 900));



        primaryStage.show();
    }


    public static void main(String[] args) throws Exception {
        Locale locale = Locale.getDefault();
        System.out.println(locale);

//        ResourceBundle rb = ResourceBundle.getBundle("application_files/lanquage_files/rb");

        DBConnection.startConnection();

        //Time Alert
        LocalTime startTime = LocalTime.of(11, 15);
        LocalTime currentTime = LocalTime.now();

        long timeDiff = ChronoUnit.MINUTES.between(currentTime,startTime);

        System.out.println(timeDiff + " minutes until start time");

        launch(args);
        DBConnection.closeConnection();
    }
}

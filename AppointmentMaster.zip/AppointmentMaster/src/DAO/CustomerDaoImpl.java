package DAO;

import application.Customer;
import com.mysql.cj.xdevapi.Statement;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Observable;

// Methods included: Create, Read, Update, Delete
public class CustomerDaoImpl {
    static boolean act;
//    public static Customer getCustomer() throws SQLException, Exception{
//        DBConnection.startConnection();
//        String sqlStatement = "SELECT * FROM customer";
//        Query.makeQuery(sqlStatement);
//        Customer customerResult;
//        ResultSet result = Query.getResult();
//        while(result.next()){
//            String customerNameG = result.getString("customerName");
//            String address = result.getString("addressId");
//            String city = result.getString("city");
////            String createdBy = result.getString("createdBy");
////            String updatedDate = result.getString("lastUpdate");
////            String updatedBy = result.getString("lastUpdateBy");
//
//            customerResult = new Customer(customerNameG, address, city);
//            return customerResult;
//        }
//        DBConnection.closeConnection();
//        return null;
//    }
    public static ObservableList<Customer> getAllCustomers() throws SQLException, Exception{
        ObservableList<Customer>
                allCustomers= FXCollections.observableArrayList();
        String sqlStatement="SELECT c.customerId, c.customerName, a.address, a.phone, t.city, n.country FROM U060i1.customer as c LEFT JOIN U060i1.address AS a ON c.addressId = a.addressID LEFT JOIN U060i1.city AS t on a.cityID = t.cityId LEFT JOIN U060i1.country AS n on t.countryId = n.countryId;";
        Query.makeQuery(sqlStatement);
        ResultSet result = Query.getResult();
        while(result.next()){
            Integer customerId = result.getInt("customerId");
            String customerNameG = result.getString("customerName");
            String address = result.getString("address");
            String city = result.getString("city");
            String country = result.getString("country");
            String phone = result.getString("phone");

            Customer customerResult = new Customer(customerId, customerNameG, address, city, country, phone);
            allCustomers.add(customerResult);
        }
        return allCustomers;

    }
    public static Integer getNextId() throws Exception {
        String countryMax = "SELECT MAX(countryId) FROM country";
        String cityMax = "SELECT MAX(cityId) FROM city";
        String addressMax = "SELECT MAX(addressId) FROM address";
        String customerMax = "SELECT MAX(customerId) FROM customer";

        Query.makeQuery(countryMax);
        ResultSet result = Query.getResult();
        result.next();
        int max = result.getInt(1);

        Query.makeQuery(cityMax);
        result = Query.getResult();
        result.next();
        max = Math.max(max, result.getInt(1));

        Query.makeQuery(addressMax);
        result = Query.getResult();
        result.next();
        max = Math.max(max, result.getInt(1));

        Query.makeQuery(customerMax);
        result = Query.getResult();
        result.next();
        max = Math.max(max, result.getInt(1));

        return max+1;
    }
}

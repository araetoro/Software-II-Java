package DAO;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    //JDBC URL parts
    private static final String protocol = "jdbc";
    private static final String vendorName = ":mysql:";
    private static final String ipAddress = "//wgudb.ucertify.com/U060i1";

    //JDBC URL
    private static final String jdbcURL = protocol + vendorName + ipAddress;

    //Driver & connection Interface Reference
    private static final String MYSQLJDBCDriver = "com.mysql.cj.jdbc.Driver";
    public static Connection conn = null;

    //Username
    private static final String userName = "U060i1";

    //Password
    private static final String password = "53688665793";

    public static Connection startConnection() {
        try {
            Class.forName(MYSQLJDBCDriver);
            conn = DriverManager.getConnection(jdbcURL, userName, password);
            System.out.println("Connection successful");
        }
        catch(ClassNotFoundException e){
            System.out.println(e.getMessage());
        }
        catch(SQLException e){
            System.out.println("Error: " + e.getMessage());
        }
        return conn;
    }

    public static void closeConnection(){
        try {
            conn.close();
            System.out.println("Connection Closed");
        }
        catch(SQLException e){
            System.out.println("Error: " + e.getMessage());

        }
    }
    public static Connection getConnection(){
        return conn;
    }


}

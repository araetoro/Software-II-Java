package DAO;

import application.User;
import com.mysql.cj.xdevapi.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Observable;

// Methods included: Create, Read, Update, Delete
public class ReportDaoImpl {


    public static ObservableList<String> getAppTypes() throws SQLException, Exception{
        ObservableList<String>
                appType= FXCollections.observableArrayList();
        String sqlStatement="SELECT type, Count(type) FROM appointment group by type";
        Query.makeQuery(sqlStatement);
        ResultSet result = Query.getResult();
        while(result.next()){
            String type = result.getString("type");
            String count = result.getString("Count(type)");

            appType.add(type);
            appType.add(count);
        }
        return appType;
    }
}

package DAO;

import application.Appointment;
import application.Report;
import application.User;
import com.mysql.cj.xdevapi.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Observable;

// Methods included: Create, Read, Update, Delete
public class ReportDaoImpl {


    public static ObservableList<Report> getAppTypes() throws SQLException, Exception{
        ObservableList<Report>
                appType= FXCollections.observableArrayList();
        String sqlStatement="SELECT type, Count(type) FROM appointment group by type;";
        Query.makeQuery(sqlStatement);
        ResultSet result = Query.getResult();
        while(result.next()){
            String type = result.getString("type");
            String count = result.getString("Count(type)");

            Report reportResult = new Report(type, count);
            appType.add(reportResult);
        }
        return appType;
    }

    public static ObservableList<Report> getAppByUser() throws SQLException, Exception{
        ObservableList<Report>
                appByUser= FXCollections.observableArrayList();
        String sqlStatement="SELECT u.userName, a.start FROM user as u INNER JOIN appointment AS a on u.userId= a.userId GROUP BY u.userName, a.start;";
        Query.makeQuery(sqlStatement);
        ResultSet result = Query.getResult();
        while(result.next()){
            String userName = result.getString("userName");
            Timestamp appStart = result.getTimestamp("start");

            //change to local time
            LocalDateTime sLdt =  appStart.toLocalDateTime();
            ZonedDateTime sZdt = sLdt.atZone(ZoneId.systemDefault());


            Report reportResult = new Report(userName, sZdt);
            appByUser.add(reportResult);
        }
        return appByUser;
    }

    public static ObservableList<Report> getAppTypesByUser() throws SQLException, Exception{
        ObservableList<Report>
                appTypeUser= FXCollections.observableArrayList();

            String sqlStatement = "SELECT u.userName, a.type, COUNT(a.type) FROM user as u INNER JOIN appointment AS a on u.userId= a.userId GROUP BY u.userName, a.type;";
            Query.makeQuery(sqlStatement);

        ResultSet result = Query.getResult();
        while(result.next()){
            String userName = result.getString("userName");
            String type = result.getString("type");
            String count = result.getString("Count(a.type)");

            Report reportResult = new Report(userName, type, count);
            appTypeUser.add(reportResult);
        }
        return appTypeUser;
    }

}

package DAO;

import application.User;
import com.mysql.cj.xdevapi.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Observable;

// Methods included: Create, Read, Update, Delete
public class UserDaoImpl {
    static boolean act;
        public static User getUser(String userName) throws SQLException, Exception{
            String sqlStatement = "SELECT * FROM user";
            Query.makeQuery(sqlStatement);
            User userResult;
            ResultSet result = Query.getResult();
            while(result.next()){
                String userNameG = result.getString("userName");
                String password = result.getString("password");
                int userId = result.getInt("userId");
                userResult = new User(userName, password, userId);
                return userResult;
            }
            return null;
        }
    public static ObservableList<User> getAllUsers() throws SQLException, Exception{

            ObservableList<User> allUsers= FXCollections.observableArrayList();

                    String sqlStatement="SELECT * FROM user";
                    Query.makeQuery(sqlStatement);
                    ResultSet result = Query.getResult();
                        while(result.next()){
                            String userNameG = result.getString("userName");
                            String password = result.getString("password");
                            int userId = result.getInt("userId");

                            User userResult = new User(userNameG, password, userId);

                            allUsers.add(userResult);
                        }
                        return allUsers;
    }
    public static HashMap<String,String> getUserPass() throws SQLException, Exception{

        HashMap<String, String> userPass = new HashMap<>();

        String sqlStatement="SELECT * FROM user";
        Query.makeQuery(sqlStatement);
        ResultSet result = Query.getResult();
        while(result.next()){
            String userNameG = result.getString("userName");
            String password = result.getString("password");
            int userId = result.getInt("userId");

            User userPassResult = new User(userNameG, password);

            userPass.put(userNameG, password);
        }
        return userPass;
    }
    public static HashMap<String, Integer> getUserIdHas() throws SQLException, Exception{

        HashMap<String, Integer> userPass = new HashMap<>();

        String sqlStatement="SELECT * FROM user";
        Query.makeQuery(sqlStatement);
        ResultSet result = Query.getResult();
        while(result.next()){
            String userNameG = result.getString("userName");
            Integer userId = result.getInt("userId");

//            User userPassResult = new User(userNameG, userId);

            userPass.put(userNameG, userId);
        }
        return userPass;
    }

}

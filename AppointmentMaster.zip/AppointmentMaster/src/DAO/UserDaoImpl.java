package DAO;

import application.User;
import com.mysql.cj.xdevapi.Statement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Observable;

// Methods included: Create, Read, Update, Delete
public class UserDaoImpl {
    static boolean act;
        public static User getUser(String userName) throws SQLException, Exception{
            String sqlStatement = "SELECT * FROM user";
            Query.makeQuery(sqlStatement);
            User userResult;
            ResultSet result = Query.getResult();
            while(result.next()){
                String userNameG = result.getString("userName");
                String password = result.getString("password");
                userResult = new User(userName, password);
                return userResult;
            }
            return null;
        }
    public static ObservableList<User> getAllUsers() throws SQLException, Exception{
            ObservableList<User>
            allUsers= FXCollections.observableArrayList();
                    String sqlStatement="SELECT * FROM user";
                    Query.makeQuery(sqlStatement);
                    ResultSet result = Query.getResult();
                        while(result.next()){
                            String userNameG = result.getString("userName");
                            String password = result.getString("password");
                            User userResult = new User(userNameG, password);
                            allUsers.add(userResult);
                        }
                        return allUsers;
    }
}

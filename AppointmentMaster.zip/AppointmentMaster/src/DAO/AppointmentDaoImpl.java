package DAO;

import application.Appointment;
import application.Customer;
import com.mysql.cj.xdevapi.Statement;
import javafx.beans.property.ReadOnlyStringWrapper;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Observable;

// Methods included: Create, Read, Update, Delete
public class AppointmentDaoImpl {
    static boolean act;
    //    public static Customer getCustomer() throws SQLException, Exception{
//        DBConnection.startConnection();
//        String sqlStatement = "SELECT * FROM customer";
//        Query.makeQuery(sqlStatement);
//        Customer customerResult;
//        ResultSet result = Query.getResult();
//        while(result.next()){
//            String customerNameG = result.getString("customerName");
//            String address = result.getString("addressId");
//            String city = result.getString("city");
////            String createdBy = result.getString("createdBy");
////            String updatedDate = result.getString("lastUpdate");
////            String updatedBy = result.getString("lastUpdateBy");
//
//            customerResult = new Customer(customerNameG, address, city);
//            return customerResult;
//        }
//        DBConnection.closeConnection();
//        return null;
//    }
    public static ObservableList<Appointment> getAllAppointments() throws SQLException, Exception{
        ObservableList<Appointment>
                allAppointments= FXCollections.observableArrayList();

        String sqlStatement="SELECT c.customerName, a.appointmentId, a.type, a.start, a.end, u.userName FROM U060i1.appointment AS a LEFT JOIN U060i1.customer as c  ON c.customerId = a.customerId LEFT JOIN U060i1.user AS u on a.userId = u.userId;";
        Query.makeQuery(sqlStatement);
        ResultSet result = Query.getResult();
        while(result.next()){
            String customerNameG = result.getString("customerName");
            String serviceAgent = result.getString("userName");
            Timestamp appStart = result.getTimestamp("start");
            Timestamp appEnd = result.getTimestamp("end");
            String appType = result.getString("type");
            Integer appId = result.getInt("appointmentId");

            Appointment appointmentResult = new Appointment(serviceAgent, customerNameG,appStart, appEnd, appType, appId);
            allAppointments.add(appointmentResult);
        }
        return allAppointments;

    }
    public static Integer getNextId() throws Exception {
        String appointmentMax = "SELECT MAX(appointmentId) FROM appointment";

        Query.makeQuery(appointmentMax);
        ResultSet result = Query.getResult();
        result.next();
        int max = result.getInt(1);

        return max+1;
    }
}
